/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assetmgt;

import java.util.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.sql.*;

/**
 *
 * @author ccslearner
 */
public class asset_rentals {
    
    public int asset_id;
    public String rental_date;
    public String reservation_date;
    public int resident_id;
    public String rental_amount;
    public String discount;
    public String status;
    public String inspection_details;
    public String assessed_value;
    public int accept_hoid;
    public String accept_position;
    public String accept_electiondate;
    public String return_date;
    public int approval_hoid;
    public String approval_position;
    public String approval_electiondate;
    public int ornum;
    public int pres_hoid;
    public String pres_position;
    public String pres_electiondate;
    
    public ArrayList<Integer> asset_idList = new ArrayList<>();
    public ArrayList<Integer> or_numList = new ArrayList<>();
    public ArrayList<String> asset_rentalsList = new ArrayList<>();
    public ArrayList<Integer> rent_idList = new ArrayList<>();
    public ArrayList<Integer> resident_idList = new ArrayList<>();
    public ArrayList<Integer> forrent_asset_idList = new ArrayList<>();
    public ArrayList<Integer> officer_idList = new ArrayList<>();
    public ArrayList<String> rent_dateList = new ArrayList<>();
    
    public asset_rentals() {
        
    }
    
    public int getValues() {
        
        try {
            //1 Connect to databse
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB??useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            //2 Prepare SQL Statements
            PreparedStatement pstmt = conn.prepareStatement("SELECT asset_id FROM assets WHERE forrent = 1 ORDER BY asset_id ASC");
            ResultSet rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

            forrent_asset_idList.clear();

            while (rst.next()) {
                int temp = rst.getInt("asset_id");

                forrent_asset_idList.add(temp);
            }
            
            pstmt = conn.prepareStatement("SELECT DISTINCT ho_id FROM officer");
            rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

            officer_idList.clear();

            while (rst.next()) {
                int temp = rst.getInt("ho_id");

                officer_idList.add(temp);
            }
            
            pstmt = conn.prepareStatement("SELECT DISTINCT resident_id FROM residents WHERE renter = 1");
            rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

            resident_idList.clear();

            while (rst.next()) {
                int temp = rst.getInt("resident_id");

                resident_idList.add(temp);
            }
            
            pstmt = conn.prepareStatement("SELECT DISTINCT transaction_date FROM asset_transactions");
            rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

            asset_rentalsList.clear();

            while (rst.next()) {
                String temp = rst.getString("transaction_date");

                asset_rentalsList.add(temp);
            }
            
            pstmt = conn.prepareStatement("SELECT DISTINCT ornum FROM ref_ornumbers;");
            rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

            or_numList.clear();

            while (rst.next()) {
                int temp = rst.getInt("ornum");

                or_numList.add(temp);
            }
            
            pstmt = conn.prepareStatement("SELECT DISTINCT asset_id FROM asset_rentals WHERE status != 'N';");
            rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

            rent_idList.clear();

            while (rst.next()) {
                int temp = rst.getInt("asset_id");

                rent_idList.add(temp);
            }
            
            pstmt = conn.prepareStatement("SELECT DISTINCT rental_date FROM asset_rentals WHERE status != 'N';");
            rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

            rent_dateList.clear();

            while (rst.next()) {
                String temp = rst.getString("rental_date");

                rent_dateList.add(temp);
            }
            
            //3 Close DB Connection
            pstmt.close();
            conn.close();

            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());

            return 0;
        }
        
    }
    
    public int recordRental() {
        
        try {
            //1 Connect to databse
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB??useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            //2 Prepare SQL Statements
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO asset_rentals (asset_id, rental_date, reservation_date, resident_id, status) VALUE (?, ?, ?, ?, ?)");
            ResultSet rst;
            
            pstmt.setInt(1, asset_id);
            pstmt.setDate(2, java.sql.Date.valueOf(rental_date));
            pstmt.setDate(3, java.sql.Date.valueOf(reservation_date));
            pstmt.setInt(4, resident_id);
            pstmt.setString(5, status);     
            
            pstmt.executeUpdate();
            
            if (rental_amount.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET rental_amount = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setString(1, rental_amount);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            if (discount.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET discount = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setString(1, discount);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            if (inspection_details.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET inspection_details = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setString(1, inspection_details);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            if (assessed_value.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET assessed_value = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setString(1, assessed_value);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            if (accept_hoid != 0) {
                pstmt = conn.prepareStatement("SELECT position, election_date FROM officer WHERE ho_id = ? ORDER BY election_date DESC LIMIT 1");
            
                pstmt.setInt(1, accept_hoid);

                rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

                while (rst.next()) {
                    accept_position = rst.getString("position");

                    accept_electiondate = rst.getString("election_date");
                }
                
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET accept_hoid = ?, accept_position = ?, accept_electiondate = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setInt(1, accept_hoid);
                pstmt.setString(2, accept_position);
                pstmt.setDate(3, java.sql.Date.valueOf(accept_electiondate));
                pstmt.setInt(4, asset_id);
                pstmt.setDate(5, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            } 
            
            
            if (approval_hoid != 0) {
                pstmt = conn.prepareStatement("SELECT position, election_date FROM officer WHERE ho_id = ? ORDER BY election_date DESC LIMIT 1");
            
                pstmt.setInt(1, approval_hoid);

                rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

                while (rst.next()) {
                    approval_position = rst.getString("position");

                    approval_electiondate = rst.getString("election_date");
                }
                
                pstmt = conn.prepareStatement("UPDATE asset_transactions SET trans_hoid = ?, trans_position = ?, trans_electiondate = ? WHERE asset_id = ? AND transaction_date = ?");
                
                pstmt.setInt(1, approval_hoid);
                pstmt.setString(2, approval_position);
                pstmt.setDate(3, java.sql.Date.valueOf(approval_electiondate));
                pstmt.setInt(4, asset_id);
                pstmt.setDate(5, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            } 
            
            if (ornum != 0) {
                pstmt = conn.prepareStatement("UPDATE asset_transactions SET ornum = ? WHERE asset_id = ? AND transaction_date = ?");
                
                pstmt.setInt(1, ornum);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            //3 Close DB Connection
            pstmt.close();
            conn.close();

            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());

            return 0;
        }
        
    }
    
    public int returnRental() {
        try {
            
            //1 Connect to databse
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB??useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            //2 Prepare SQL Statements
            PreparedStatement pstmt = conn.prepareStatement("UPDATE asset_rentals SET status = 'N', return_date = DATE(NOW()) WHERE asset_id = ? AND rental_date = ?");
            
            pstmt.setInt(1, asset_id);
            pstmt.setDate(2, java.sql.Date.valueOf(rental_date));
            
            pstmt.executeUpdate();
            
            //3 Close DB Connection
            pstmt.close();
            conn.close();
            
            return 1;
            
        } catch (Exception e) {
            System.out.println(e.getMessage());

            return 0;
        }
    }
    
    public int updateRental() {
        try {
            
            //1 Connect to databse
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB??useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");
            
            //2 Prepare SQL Statements
            PreparedStatement pstmt = conn.prepareStatement("UPDATE asset_rentals SET reservation_date = ? WHERE asset_id = ? AND rental_date = ?");
            ResultSet rst;
            
            if (reservation_date.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET reservation_date = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setString(1, reservation_date);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            if (resident_id != 0) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET resident_id = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setInt(1, resident_id);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            if (status.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET status = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setString(1, status);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            if (rental_amount.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET rental_amount = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setString(1, rental_amount);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            if (discount.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET discount = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setString(1, discount);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            if (inspection_details.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET inspection_details = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setString(1, inspection_details);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }
            
            if (assessed_value.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE asset_rentals SET assessed_value = ? WHERE asset_id = ? AND rental_date = ?");
                
                pstmt.setString(1, assessed_value);
                pstmt.setInt(2, asset_id);
                pstmt.setDate(3, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            }            
            
            if (accept_hoid != 1) {
                if (accept_hoid == 0) {
                    pstmt = conn.prepareStatement("UPDATE asset_rentals SET accept_hoid = null, accept_position = null, accept_electiondate = null WHERE asset_id = ? AND rental_date = ?");

                    pstmt.setInt(1, asset_id);
                    pstmt.setDate(2, java.sql.Date.valueOf(rental_date));

                    pstmt.executeUpdate();
                } else {
                    pstmt = conn.prepareStatement("SELECT position, election_date FROM officer WHERE ho_id = ? ORDER BY election_date DESC LIMIT 1");
            
                    pstmt.setInt(1, accept_hoid);

                    rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

                    while (rst.next()) {
                        accept_position = rst.getString("position");

                        accept_electiondate = rst.getString("election_date");
                    }

                    pstmt = conn.prepareStatement("UPDATE asset_rentals SET accept_hoid = ?, accept_position = ?, accept_electiondate = ? WHERE asset_id = ? AND rental_date = ?");

                    pstmt.setInt(1, accept_hoid);
                    pstmt.setString(2, accept_position);
                    pstmt.setDate(3, java.sql.Date.valueOf(accept_electiondate));
                    pstmt.setInt(4, asset_id);
                    pstmt.setDate(5, java.sql.Date.valueOf(rental_date));

                    pstmt.executeUpdate();
                }  
            }
            
            if (approval_hoid != 0) {
                pstmt = conn.prepareStatement("SELECT position, election_date FROM officer WHERE ho_id = ? ORDER BY election_date DESC LIMIT 1");
            
                pstmt.setInt(1, approval_hoid);

                rst = pstmt.executeQuery();//for SELECT (may nagrereturn)

                while (rst.next()) {
                    approval_position = rst.getString("position");

                    approval_electiondate = rst.getString("election_date");
                }
                
                pstmt = conn.prepareStatement("UPDATE asset_transactions SET trans_hoid = ?, trans_position = ?, trans_electiondate = ? WHERE asset_id = ? AND transaction_date = ?");
                
                pstmt.setInt(1, approval_hoid);
                pstmt.setString(2, approval_position);
                pstmt.setDate(3, java.sql.Date.valueOf(approval_electiondate));
                pstmt.setInt(4, asset_id);
                pstmt.setDate(5, java.sql.Date.valueOf(rental_date));
                
                pstmt.executeUpdate();
            } 
            
            if (ornum != 1) {
                if (ornum == 0) {
                    pstmt = conn.prepareStatement("UPDATE asset_transactions SET ornum = null WHERE asset_id = ? AND transaction_date = ?");

                    pstmt.setInt(1, asset_id);
                    pstmt.setDate(2, java.sql.Date.valueOf(rental_date));

                    pstmt.executeUpdate();
                } else {
                    pstmt = conn.prepareStatement("UPDATE asset_transactions SET ornum = ? WHERE asset_id = ? AND transaction_date = ?");
                
                    pstmt.setInt(1, ornum);
                    pstmt.setInt(2, asset_id);
                    pstmt.setDate(3, java.sql.Date.valueOf(rental_date));

                    pstmt.executeUpdate();
                }
                
            }
            
            //3 Close DB Connection
            pstmt.close();
            conn.close();
            
            return 1;
            
        } catch (Exception e) {
            System.out.println(e.getMessage());

            return 0;
        }
    }
    
    public int deleteRental() {
        try {
            
            //1 Connect to databse
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB??useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            //2 Prepare SQL Statements
            PreparedStatement pstmt = conn.prepareStatement("SELECT ho_id, position, election_date FROM officer_presidents ORDER BY election_date DESC LIMIT 1");
            ResultSet rst = pstmt.executeQuery();//for SELECT (may nagrereturn)
            
            while (rst.next()) {
                pres_hoid = rst.getInt("ho_id");
                pres_position = rst.getString("position");
                pres_electiondate = rst.getString("election_date");
            }
            
            pstmt = conn.prepareStatement("UPDATE asset_transactions SET isdeleted = 1, approval_hoid = ?, approval_position = ?, approval_electiondate = ? WHERE asset_id = ? AND transaction_date = ?");
            
            pstmt.setInt(1, pres_hoid);
            pstmt.setString(2, pres_position);
            pstmt.setString(3, pres_electiondate);
            pstmt.setInt(4, asset_id);
            pstmt.setDate(5, java.sql.Date.valueOf(rental_date));
            
            pstmt.executeUpdate();
            
            //3 Close DB Connection
            pstmt.close();
            conn.close();
            
            return 1;
            
        } catch (Exception e) {
            System.out.println(e.getMessage());

            return 0;
        }
    }
    
    public static void main(String args[]) {
        asset_rentals B = new asset_rentals();
        
        B.asset_id = 5001;
        B.rental_date = "2022-12-21";
        B.reservation_date = "2022-12-15";
        B.resident_id = 9002;
        B.status = "N";
        
        B.rental_amount = "0.05";
        B.discount = "0.04";
        B.inspection_details = "All returned ok";
        B.assessed_value = "0.05";
        B.accept_hoid = 0;
        B.return_date = "";
        
        B.accept_hoid = 9010;
        
        B.approval_hoid = 9009;
        B.ornum = 3000006;

        System.out.println(B.deleteRental());
    }
    
}

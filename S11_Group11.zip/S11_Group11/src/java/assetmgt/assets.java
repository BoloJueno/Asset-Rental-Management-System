/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assetmgt;

import java.util.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.sql.*;

/**
 *
 * @author ccslearner
 */
public class assets {
    
    //Attributes
    public int asset_id;
    public String asset_name;
    public String asset_description;
    public String acquisition_date;
    public String forrent;
    public String asset_value;
    public String type_asset;
    public String status;
    public String loc_lattitude;
    public String loc_longiture;
    public String hoa_name;
    public String enclosing_asset;

    //List of assets
    public ArrayList<Integer> asset_idList = new ArrayList<>();
    public ArrayList<Integer> forrent_asset_idList = new ArrayList<>();
    public ArrayList<String> asset_nameList = new ArrayList<> ();
    public ArrayList<String> hoa_nameList = new ArrayList<>();
    public ArrayList<Integer> enclosing_assetList = new ArrayList<>();
    
    public assets() {
        
    }
    
    public int getValues() {
        try {
            //1 Connect to databse
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB??useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");
            
            //2 Prepare SQL Statements
            PreparedStatement pstmt = conn.prepareStatement("SELECT hoa_name FROM hoa");
            ResultSet rst = pstmt.executeQuery();//for SELECT (may nagrereturn)
            
            hoa_nameList.clear();
            
            while (rst.next()) {
                hoa_name = rst.getString("hoa_name");
                
                hoa_nameList.add(hoa_name);
            }
            
            pstmt = conn.prepareStatement("SELECT asset_id FROM assets ORDER BY asset_id ASC");
            rst = pstmt.executeQuery();//for SELECT (may nagrereturn)
            
            asset_idList.clear();
            
            while (rst.next()) {
                asset_id = rst.getInt("asset_id");
                
                asset_idList.add(asset_id);
            }
            
            pstmt = conn.prepareStatement("SELECT asset_id FROM assets WHERE forrent = 1 ORDER BY asset_id ASC");
            rst = pstmt.executeQuery();//for SELECT (may nagrereturn)
            
            forrent_asset_idList.clear();
            
            while (rst.next()) {
                asset_id = rst.getInt("asset_id");
                
                forrent_asset_idList.add(asset_id);
            }
            
            
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            
            return 0;
        }
    }
    
    public int register_asset() {
        try {
            //1 Connect to databse
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB??useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");
            
            //2 Prepare SQL Statements
            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(asset_id) + 1 AS newID FROM assets");
            ResultSet rst = pstmt.executeQuery();//for SELECT (may nagrereturn)
            
            while (rst.next()) {
                asset_id = rst.getInt("newID");
            }
            
//            asset_name = "asdf";
//            asset_description = "asdf";
//            acquisition_date = "2002-02-02";
//            forrent = "0";
//            asset_value = "100.20";
//            type_asset = "F";
//            status = "W";
//            loc_lattitude = "12";
//            loc_longiture = "12";
//            hoa_name = "SJH";
//            enclosing_asset = "5006";
            
            if (enclosing_asset.equals("0")) {
                pstmt = conn.prepareStatement("INSERT INTO assets (asset_id, asset_name, asset_description, acquisition_date, forrent, asset_value, type_asset, status, loc_lattitude, loc_longiture, hoa_name) VALUE (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            } else {
                pstmt = conn.prepareStatement("INSERT INTO assets (asset_id, asset_name, asset_description, acquisition_date, forrent, asset_value, type_asset, status, loc_lattitude, loc_longiture, hoa_name, enclosing_asset) VALUE (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            }    
            
            pstmt.setInt(1, asset_id);
            pstmt.setString(2, asset_name);
            pstmt.setString(3, asset_description);
            
            pstmt.setDate(4, java.sql.Date.valueOf(acquisition_date));
            
            if (forrent.equals("0")) {
                pstmt.setBoolean(5, false);
            } else {
                pstmt.setBoolean(5, true);
            }
            
            pstmt.setFloat(6, Float.parseFloat(asset_value));
            pstmt.setString(7, type_asset);
            pstmt.setString(8, status);
            pstmt.setFloat(9, Float.parseFloat(loc_lattitude));
            pstmt.setFloat(10, Float.parseFloat(loc_longiture));
            pstmt.setString(11, hoa_name);
            
            if (enclosing_asset.equals("0") == false) {
                pstmt.setInt(12, Integer.parseInt(enclosing_asset));
            }

            pstmt.executeUpdate();//for INSERT (walang result na bumabalik)
            
            //3 Close DB Connection
            pstmt.close();
            conn.close();
            
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            
            return 0;
        }
        
    }
    
    public int update_asset() {
        try {
            //1 Connect to databse
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB??useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");
            
            //2 Prepare SQL Statements
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM assets");
            
            //            asset_name = "asdf";
//            asset_description = "asdf";
//            acquisition_date = "2002-02-02";
//            forrent = "0";
//            asset_value = "100.20";
//            type_asset = "F";
//            status = "W";
//            loc_lattitude = "12";
//            loc_longiture = "12";
//            hoa_name = "SJH";
//            enclosing_asset = "5006";
            
            if (asset_name.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET asset_name = ? WHERE asset_id = ?");
                
                pstmt.setString(1, asset_name);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            }
            
            if (asset_description.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET asset_description = ? WHERE asset_id = ?");
                
                pstmt.setString(1, asset_description);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            }
            
            if (acquisition_date.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET acquisition_date = ? WHERE asset_id = ?");
                
                pstmt.setString(1, acquisition_date);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            }
            
            if (forrent.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET forrent = ? WHERE asset_id = ?");
                
                pstmt.setString(1, forrent);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            }
            
            if (asset_value.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET asset_value = ? WHERE asset_id = ?");
                
                pstmt.setString(1, asset_value);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            }
            
            if (type_asset.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET type_asset = ? WHERE asset_id = ?");
                
                pstmt.setString(1, type_asset);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            }
            
            if (status.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET status = ? WHERE asset_id = ?");
                
                pstmt.setString(1, status);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            }
            
            if (loc_lattitude.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET loc_lattitude = ? WHERE asset_id = ?");
                
                pstmt.setString(1, loc_lattitude);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            }
            
            if (loc_longiture.equals("") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET loc_longiture = ? WHERE asset_id = ?");
                
                pstmt.setString(1, loc_longiture);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            }
            
            if (hoa_name.equals("0") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET hoa_name = ? WHERE asset_id = ?");
                
                pstmt.setString(1, hoa_name);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            }
            
            if (enclosing_asset.equals("") == true) {
                pstmt = conn.prepareStatement("UPDATE assets SET enclosing_asset = NULL WHERE asset_id = ?");
                
                pstmt.setInt(1, asset_id);  
                
                pstmt.executeUpdate();
            } else if (enclosing_asset.equals("0") == false) {
                pstmt = conn.prepareStatement("UPDATE assets SET enclosing_asset = ? WHERE asset_id = ?");
                
                pstmt.setString(1, enclosing_asset);
                pstmt.setInt(2, asset_id);  
                
                pstmt.executeUpdate();
            } 
            
            //3 Close DB Connection
            pstmt.close();
            conn.close();
            
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            
            return 0;
        }
    }
    
    public int delete_asset(){
        
        try{
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB??useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM assets WHERE asset_id = ?;");
            
            pstmt.setInt(1, asset_id);

            pstmt.executeUpdate();
            
            pstmt.close();
            conn.close();
            
            return 1;
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int UnusedAssets () {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");
            PreparedStatement pstmt = conn.prepareStatement("SELECT asset_id, asset_name FROM assets WHERE asset_id NOT IN (SELECT asset_id FROM asset_activity) AND asset_id NOT IN (SELECT asset_id FROM asset_rentals) ORDER BY asset_id");
            ResultSet rst = pstmt.executeQuery();           
            asset_idList.clear();
            asset_nameList.clear();

            while (rst.next()) {
                 asset_id = rst.getInt("asset_id");
                 asset_name = rst.getString("asset_name");
                 asset_idList.add(asset_id);
                 asset_nameList.add(asset_name);
            }
            pstmt.close();
            conn.close();

            System.out.println("Yay! Successful");
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
     public int getAssetsForDisposal () {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");
            PreparedStatement pstmt = conn.prepareStatement("SELECT asset_id, asset_name FROM assets WHERE status='S'");
            ResultSet rst = pstmt.executeQuery();
            asset_idList.clear();
            asset_nameList.clear();

            while (rst.next()) {
                 asset_id = rst.getInt("asset_id");
                 asset_name = rst.getString("asset_name");
                 asset_idList.add(asset_id);
                 asset_nameList.add(asset_name);
            }
            pstmt.close();
            conn.close();

            System.out.println("Successful");
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
     
    public int dispose_asset(){
        try{
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/HOADB?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");
            
            
            PreparedStatement pstmt = conn.prepareStatement("UPDATE assets SET status='X' WHERE asset_id = ?;");
            pstmt.setInt(1, asset_id);

            
            pstmt.executeUpdate();
            
            pstmt.close();
            conn.close();
            
            System.out.println("Successful");
            return 1;
            
        } catch(Exception e){
            System.out.println(e.getMessage());
            return 0;
        }
        
    }
    
    public static void main(String args[]) {
        assets A = new assets();
        
        A.asset_id = 5001;
        A.enclosing_asset = "";
        
        System.out.println(A.update_asset());
        
    }
    
}
